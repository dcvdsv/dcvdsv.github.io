package com.atguigu.zhxy.mapper;

import com.atguigu.zhxy.pojo.Admin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

/**
 *@Author: feifan
 *@Date: 2022/6/7 10:40
 */
@Repository
public interface AdminMapper extends BaseMapper<Admin> {
}
