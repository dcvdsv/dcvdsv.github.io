package com.atguigu.zhxy.mapper;

import com.atguigu.zhxy.pojo.Clazz;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 *@Author: feifan
 *@Date: 2022/6/7 10:41
 */
public interface ClazzMapper extends BaseMapper<Clazz> {
}
