package com.atguigu.zhxy.mapper;

import com.atguigu.zhxy.pojo.Grade;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 *@Author: feifan
 *@Date: 2022/6/7 10:42
 */
public interface GradeMapper extends BaseMapper<Grade> {
}
