package com.atguigu.zhxy.mapper;

import com.atguigu.zhxy.pojo.Teacher;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 *@Author: feifan
 *@Date: 2022/6/7 10:43
 */
public interface TeacherMapper extends BaseMapper<Teacher> {
}
